<?php
session_start();
include 'koneksi.php';

// Inisialisasi keranjang jika belum ada
if (!isset($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = array();
}

// Tangani aksi tambah, update, hapus dari keranjang
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $id_produk = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $qty = isset($_GET['qty']) ? (int)$_GET['qty'] : 1;

    switch ($action) {
        case 'add':
            // Pastikan produk ada dan stok cukup
            $stmt_check_product = $koneksi->prepare("SELECT nama_produk, harga, stok FROM produk WHERE id_produk = ?");
            $stmt_check_product->bind_param("i", $id_produk);
            $stmt_check_product->execute();
            $result_check_product = $stmt_check_product->get_result();

            if ($result_check_product->num_rows > 0) {
                $produk_data = $result_check_product->fetch_assoc();
                $stok_tersedia = $produk_data['stok'];

                // Jika produk sudah ada di keranjang, tambahkan jumlahnya
                if (isset($_SESSION['keranjang'][$id_produk])) {
                    $new_qty = $_SESSION['keranjang'][$id_produk]['quantity'] + $qty;
                } else {
                    $new_qty = $qty;
                }

                if ($new_qty <= $stok_tersedia) {
                    $_SESSION['keranjang'][$id_produk] = [
                        'id_produk' => $id_produk,
                        'nama_produk' => $produk_data['nama_produk'],
                        'harga' => $produk_data['harga'],
                        'quantity' => $new_qty
                    ];
                    echo "<script>alert('Produk berhasil ditambahkan ke keranjang!');</script>";
                } else {
                    echo "<script>alert('Jumlah yang diminta melebihi stok tersedia!');</script>";
                }
            } else {
                echo "<script>alert('Produk tidak ditemukan!');</script>";
            }
            $stmt_check_product->close();
            break;

        case 'update':
            if (isset($_SESSION['keranjang'][$id_produk])) {
                $stmt_check_product = $koneksi->prepare("SELECT stok FROM produk WHERE id_produk = ?");
                $stmt_check_product->bind_param("i", $id_produk);
                $stmt_check_product->execute();
                $result_check_product = $stmt_check_product->get_result();
                $produk_data = $result_check_product->fetch_assoc();
                $stok_tersedia = $produk_data['stok'];

                if ($qty > 0 && $qty <= $stok_tersedia) {
                    $_SESSION['keranjang'][$id_produk]['quantity'] = $qty;
                    echo "<script>alert('Jumlah produk berhasil diupdate!');</script>";
                } elseif ($qty <= 0) {
                    unset($_SESSION['keranjang'][$id_produk]); // Hapus jika jumlah 0
                    echo "<script>alert('Produk dihapus dari keranjang!');</script>";
                } else {
                     echo "<script>alert('Jumlah yang diminta melebihi stok tersedia!');</script>";
                }
                $stmt_check_product->close();
            }
            break;

        case 'remove':
            if (isset($_SESSION['keranjang'][$id_produk])) {
                unset($_SESSION['keranjang'][$id_produk]);
                echo "<script>alert('Produk berhasil dihapus dari keranjang!');</script>";
            }
            break;

        case 'clear':
            unset($_SESSION['keranjang']);
            $_SESSION['keranjang'] = []; // Re-initialize to empty array
            echo "<script>alert('Keranjang belanja berhasil dikosongkan!');</script>";
            break;
    }
    // Redirect untuk menghindari pengiriman ulang form saat refresh
    header("Location: keranjang.php");
    exit();
}

// Ambil data keranjang dari sesi
$keranjang = isset($_SESSION['keranjang']) ? $_SESSION['keranjang'] : [];
$grand_total = 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Keranjang Belanja</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* CSS tambahan untuk keranjang */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions-cell button, .actions-cell a {
            padding: 5px 10px;
            margin-right: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            color: white;
            display: inline-block;
        }
        .update-btn { background-color: #007bff; }
        .remove-btn { background-color: #dc3545; }
        .update-btn:hover { background-color: #0056b3; }
        .remove-btn:hover { background-color: #c82333; }
        .total-row strong {
            font-size: 1.2em;
            color: #333;
        }
        .keranjang-actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .keranjang-actions a, .keranjang-actions button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            color: white;
            font-size: 1em;
        }
        .checkout-btn { background-color: #28a745; }
        .lanjut-belanja-btn { background-color: #6c757d; }
        .clear-cart-btn { background-color: #dc3545; }
        .checkout-btn:hover { background-color: #218838; }
        .lanjut-belanja-btn:hover { background-color: #5a6268; }
        .clear-cart-btn:hover { background-color: #c82333; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Toko Elektronik</h1>
        <nav>
            <a href="index.php">Beranda</a> |
            <a href="keranjang.php">Keranjang</a> |
            <?php if (isset($_SESSION['level'])): ?>
                <?php if ($_SESSION['level'] == 'admin'): ?>
                    <a href="dashboard_admin.php">Dashboard Admin</a> |
                <?php else: ?>
                    <a href="riwayat_pesanan.php">Riwayat Pesanan</a> |
                <?php endif; ?>
                <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span> |
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a> |
                <a href="register.php">Daftar</a>
            <?php endif; ?>
        </nav>
    </div>

    <h2>Keranjang Belanja Anda</h2>
    <?php if (empty($keranjang)): ?>
        <p>Keranjang Anda kosong. Yuk, <a href="index.php">mulai belanja!</a></p>
    <?php else: ?>
        <table border="1">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Produk</th>
                    <th>Harga Satuan</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($keranjang as $id_produk => $item) {
                    $subtotal = $item['harga'] * $item['quantity'];
                    $grand_total += $subtotal;
                ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($item['nama_produk']); ?></td>
                    <td>Rp <?= number_format($item['harga'], 0, ',', '.'); ?></td>
                    <td>
                        <form action="keranjang.php" method="GET" style="display:inline;">
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($id_produk); ?>">
                            <input type="number" name="qty" value="<?= htmlspecialchars($item['quantity']); ?>" min="1" style="width: 50px;">
                            <button type="submit" class="update-btn">Update</button>
                        </form>
                    </td>
                    <td>Rp <?= number_format($subtotal, 0, ',', '.'); ?></td>
                    <td class="actions-cell">
                        <a href="keranjang.php?action=remove&id=<?= htmlspecialchars($id_produk); ?>" class="remove-btn">Hapus</a>
                    </td>
                </tr>
                <?php } ?>
                <tr class="total-row">
                    <td colspan="4"><strong>Total Keseluruhan</strong></td>
                    <td colspan="2"><strong>Rp <?= number_format($grand_total, 0, ',', '.'); ?></strong></td>
                </tr>
            </tbody>
        </table>

        <div class="keranjang-actions">
            <a href="checkout.php" class="checkout-btn">Lanjutkan ke Checkout</a>
            <a href="index.php" class="lanjut-belanja-btn">Lanjutkan Belanja</a>
            <a href="keranjang.php?action=clear" class="clear-cart-btn" onclick="return confirm('Apakah Anda yakin ingin mengosongkan keranjang?');">Kosongkan Keranjang</a>
        </div>
    <?php endif; ?>
</body>
</html>