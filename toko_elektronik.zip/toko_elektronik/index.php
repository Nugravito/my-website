<?php
session_start(); // Pastikan session dimulai di awal
include 'koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Beranda - Toko Elektronik</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h1>Toko Elektronik</h1>
        <nav>
            <a href="index.php">Beranda</a> |
            <a href="keranjang.php">Keranjang</a> |
            <?php if (isset($_SESSION['level'])): // Jika sudah login ?>
                <?php if ($_SESSION['level'] == 'admin'): ?>
                    <a href="dashboard_admin.php">Dashboard Admin</a> |
                <?php else: // Jika levelnya 'user' ?>
                    <a href="riwayat_pesanan.php">Riwayat Pesanan</a> |
                <?php endif; ?>
                <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span> |
                <a href="logout.php">Logout</a>
            <?php else: // Jika belum login ?>
                <a href="login.php">Login</a> |
                <a href="register.php">Daftar</a>
            <?php endif; ?>
        </nav>
    </div>

    <h2>Produk Tersedia</h2>
    <div class="produk-container">
        <?php
        // Menggunakan Prepared Statement untuk query produk (walaupun tanpa input user, tetap praktik baik)
        $stmt = $koneksi->prepare("SELECT id_produk, nama_produk, harga, gambar FROM produk ORDER BY nama_produk ASC");
        // No bind_param() needed as there are no parameters
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($data = $result->fetch_assoc()) {
        ?>
            <div class="produk">
                <img src="img/<?php echo htmlspecialchars($data['gambar']); ?>" alt="<?php echo htmlspecialchars($data['nama_produk']); ?>" width="150"><br>
                <strong><?php echo htmlspecialchars($data['nama_produk']); ?></strong><br>
                Rp <?php echo number_format($data['harga'], 0, ',', '.'); ?><br>
                <a href="detail_produk.php?id=<?php echo htmlspecialchars($data['id_produk']); ?>">Lihat Detail / Beli</a>
            </div>
        <?php
            }
        } else {
            echo "<p>Belum ada produk tersedia.</p>";
        }
        $stmt->close();
        ?>
    </div>
</body>
</html>