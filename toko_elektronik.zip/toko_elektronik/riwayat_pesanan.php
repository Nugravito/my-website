<?php
session_start();
include 'koneksi.php';

// Pastikan hanya pelanggan yang bisa mengakses
if (!isset($_SESSION['id_pelanggan']) || $_SESSION['level'] != 'user') {
    echo "Anda harus login sebagai pelanggan untuk melihat riwayat pesanan.";
    header("location:login.php"); // Redirect ke halaman login
    exit();
}

$id_pelanggan = $_SESSION['id_pelanggan']; // Ini diambil dari sesi login pelanggan

// Query untuk mendapatkan semua pesanan pelanggan ini
$stmt_pesanan = $koneksi->prepare("SELECT id_pesanan, tanggal_pesanan, total_harga, status_pesanan, nama_penerima, alamat_pengiriman, telepon_penerima FROM pesanan WHERE id_pelanggan = ? ORDER BY tanggal_pesanan DESC");
if ($stmt_pesanan === false) {
    error_log("Error preparing riwayat pesanan statement: " . $koneksi->error);
    die("Terjadi masalah saat mengambil riwayat pesanan.");
}
$stmt_pesanan->bind_param("i", $id_pelanggan);
$stmt_pesanan->execute();
$result_pesanan = $stmt_pesanan->get_result();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Pesanan Saya - Toko Elektronik</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .pesanan-item {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .pesanan-item h3 {
            margin-top: 0;
            color: #007bff;
        }
        .pesanan-info {
            margin-bottom: 10px;
            font-size: 0.95em;
        }
        .pesanan-info span {
            display: inline-block;
            margin-right: 20px;
            color: #555;
        }
        .pesanan-info strong {
            color: #333;
        }
        .detail-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .detail-table th, .detail-table td {
            border: 1px solid #eee;
            padding: 8px;
            text-align: left;
            font-size: 0.9em;
        }
        .detail-table th {
            background-color: #e9e9e9;
        }
        .status-pending { color: orange; font-weight: bold; }
        .status-diproses { color: blue; font-weight: bold; }
        .status-dikirim { color: green; font-weight: bold; }
        .status-selesai { color: darkgreen; font-weight: bold; }
        .status-dibatalkan { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Toko Elektronik</h1>
        <nav>
            <a href="index.php">Beranda</a> |
            <a href="keranjang.php">Keranjang</a> |
            <?php if (isset($_SESSION['level'])): ?>
                <?php if ($_SESSION['level'] == 'admin'): ?>
                    <a href="dashboard_admin.php">Dashboard Admin</a> |
                <?php else: ?>
                    <a href="riwayat_pesanan.php">Riwayat Pesanan</a> |
                <?php endif; ?>
                <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span> |
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a> |
                <a href="register.php">Daftar</a>
            <?php endif; ?>
        </nav>
    </div>

    <h2>Riwayat Pesanan Anda</h2>
    <?php if ($result_pesanan->num_rows == 0): ?>
        <p>Anda belum memiliki riwayat pesanan.</p>
    <?php else: ?>
        <?php while ($pesanan = $result_pesanan->fetch_assoc()): ?>
            <div class="pesanan-item">
                <h3>Pesanan ID: #<?php echo htmlspecialchars($pesanan['id_pesanan']); ?></h3>
                <div class="pesanan-info">
                    <span>Tanggal Pesan: <strong><?php echo htmlspecialchars(date('d F Y H:i', strtotime($pesanan['tanggal_pesanan']))); ?></strong></span>
                    <span>Total: <strong>Rp <?php echo number_format($pesanan['total_harga'], 0, ',', '.'); ?></strong></span>
                    <span>Status: <strong class="status-<?php echo strtolower($pesanan['status_pesanan']); ?>"><?php echo htmlspecialchars(ucfirst($pesanan['status_pesanan'])); ?></strong></span>
                </div>
                <div class="pesanan-info">
                    <span>Penerima: <strong><?php echo htmlspecialchars($pesanan['nama_penerima']); ?></strong></span>
                    <span>Telepon: <strong><?php echo htmlspecialchars($pesanan['telepon_penerima']); ?></strong></span>
                </div>
                <p>Alamat: <?php echo nl2br(htmlspecialchars($pesanan['alamat_pengiriman'])); ?></p>

                <h4>Detail Produk:</h4>
                <table class="detail-table">
                    <thead>
                        <tr>
                            <th>Nama Produk</th>
                            <th>Harga Satuan</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Query untuk mendapatkan detail produk dari pesanan ini
                        $id_pesanan_detail = $pesanan['id_pesanan'];
                        $stmt_detail = $koneksi->prepare("SELECT dp.jumlah, dp.harga_satuan, p.nama_produk
                                                             FROM detail_pesanan dp
                                                             JOIN produk p ON dp.id_produk = p.id_produk
                                                             WHERE dp.id_pesanan = ?");
                        if ($stmt_detail === false) {
                            error_log("Error preparing detail pesanan statement: " . $koneksi->error);
                            echo "<tr><td colspan='4'>Gagal mengambil detail produk.</td></tr>";
                        } else {
                            $stmt_detail->bind_param("i", $id_pesanan_detail);
                            $stmt_detail->execute();
                            $result_detail = $stmt_detail->get_result();

                            if ($result_detail->num_rows > 0) {
                                while ($detail = $result_detail->fetch_assoc()):
                        ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($detail['nama_produk']); ?></td>
                                    <td>Rp <?php echo number_format($detail['harga_satuan'], 0, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars($detail['jumlah']); ?></td>
                                    <td>Rp <?php echo number_format($detail['harga_satuan'] * $detail['jumlah'], 0, ',', '.'); ?></td>
                                </tr>
                        <?php
                                endwhile;
                            } else {
                                echo "<tr><td colspan='4'>Tidak ada detail produk untuk pesanan ini.</td></tr>";
                            }
                            $stmt_detail->close();
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
    <?php $result_pesanan->close(); $stmt_pesanan->close(); // Close main pesanan statement ?>
    <p><a href="index.php">Kembali ke Beranda</a></p>
</body>
</html>