<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "Akses ditolak!";
    exit();
}

if (isset($_POST['submit'])) {
    $username = htmlspecialchars(trim($_POST['username']));
    $password_input = $_POST['password']; // Password plain text dari form

    // Validasi input
    if (empty($username) || empty($password_input)) {
        echo "<script>alert('Username dan Password harus diisi!');</script>";
    } else {
        // HASH PASSWORD
        $hashed_password = password_hash($password_input, PASSWORD_DEFAULT);

        // Periksa apakah username sudah ada
        $stmt_check = $koneksi->prepare("SELECT COUNT(*) FROM user WHERE username = ?");
        if ($stmt_check === false) {
            error_log("Error preparing check user statement: " . $koneksi->error);
            echo "<script>alert('Terjadi masalah sistem. Silakan coba lagi.');</script>";
        } else {
            $stmt_check->bind_param("s", $username);
            $stmt_check->execute();
            $stmt_check->bind_result($count);
            $stmt_check->fetch();
            $stmt_check->close();

            if ($count > 0) {
                echo "<script>alert('Username sudah ada. Silakan gunakan username lain.');</script>";
            } else {
                // Gunakan Prepared Statement untuk INSERT user baru
                $stmt_insert = $koneksi->prepare("INSERT INTO user (username, password, level) VALUES (?, ?, 'admin')");
                if ($stmt_insert === false) {
                    error_log("Error preparing insert user statement: " . $koneksi->error);
                    echo "<script>alert('Gagal menambahkan admin: " . $koneksi->error . "');</script>";
                } else {
                    $stmt_insert->bind_param("ss", $username, $hashed_password);
                    if ($stmt_insert->execute()) {
                        echo "<script>alert('Admin baru berhasil ditambahkan.'); window.location.href='dashboard_admin.php';</script>";
                    } else {
                        error_log("Error executing insert admin: " . $stmt_insert->error);
                        echo "<script>alert('Gagal menambahkan admin. Silakan coba lagi.');</script>";
                    }
                    $stmt_insert->close();
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Admin Baru - Toko Elektronik Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-container {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }
        .btn-submit {
            padding: 12px 25px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1.1em;
            width: 100%;
            box-sizing: border-box;
            margin-top: 15px;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Tambah Admin Baru</h1>
        <nav>
            <a href="dashboard_admin.php">Kembali ke Dashboard</a>
        </nav>
    </div>

    <div class="form-container">
        <h2>Form Tambah Admin Baru</h2>
        <form method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="submit" class="btn-submit">Tambah Admin</button>
        </form>
    </div>
</body>
</html>