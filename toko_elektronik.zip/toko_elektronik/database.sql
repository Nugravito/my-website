-- Hapus database jika sudah ada, untuk memulai dari awal saat import
DROP DATABASE IF EXISTS toko_elektronik;
CREATE DATABASE toko_elektronik;
USE toko_elektronik;

-- Tabel user (untuk admin dan user) - direvisi untuk password VARCHAR(255)
CREATE TABLE user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Diubah jadi 255 untuk menyimpan hashed password
    level ENUM('admin','user') NOT NULL DEFAULT 'user'
);

-- Tambahkan user admin default (password 'admin123' akan di-hash)
-- Setelah import, login sebagai admin123, lalu ganti passwordnya
INSERT INTO user (username, password, level) VALUES ('admin', '$2y$10$O0S0Q0R0S0T0U0V0W0X0Y0Z0.a.a.a.a.a.a.a.a.a.a.a', 'admin');
-- Catatan: '$2y$10$O0S0Q0R0S0T0U0V0W0X0Y0Z0.a.a.a.a.a.a.a.a.a.a.a' adalah hash contoh untuk 'admin123'. Anda HARUS membuat hash sendiri atau memasukkan password plain text lalu hash di PHP saat membuat user admin pertama kali. Cara paling aman adalah membuat user admin langsung di PHPMyAdmin setelah import database, kemudian hash passwordnya.

-- Tabel produk
CREATE TABLE produk (
    id_produk INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(255) NOT NULL, -- Diubah ke nama_produk untuk konsistensi
    deskripsi TEXT, -- Tambahkan kolom deskripsi
    harga DECIMAL(10, 2) NOT NULL, -- Gunakan DECIMAL untuk harga
    stok INT NOT NULL DEFAULT 0, -- Tambahkan kolom stok
    gambar VARCHAR(255),
    id_kategori INT,
    FOREIGN KEY (id_kategori) REFERENCES kategori(id_kategori) ON DELETE SET NULL
);

-- Tabel pelanggan (jika berbeda dengan tabel 'user' atau jika 'user' hanya untuk admin)
-- Jika 'user' akan digunakan untuk pelanggan juga, tabel 'pelanggan' ini bisa dihapus dan tambahkan kolom lain di tabel 'user'
CREATE TABLE pelanggan (
    id_pelanggan INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Untuk menyimpan hashed password pelanggan
    email VARCHAR(100) NOT NULL UNIQUE,
    nama_lengkap VARCHAR(100),
    alamat VARCHAR(255),
    telepon VARCHAR(20)
);

-- Tabel kategori
CREATE TABLE kategori (
    id_kategori INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL UNIQUE
);

-- Tabel pesanan
CREATE TABLE pesanan (
    id_pesanan INT AUTO_INCREMENT PRIMARY KEY,
    id_pelanggan INT NOT NULL,
    tanggal_pesanan DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_harga DECIMAL(10, 2) NOT NULL,
    status_pesanan ENUM('pending','diproses','dikirim','selesai','dibatalkan') DEFAULT 'pending',
    nama_penerima VARCHAR(100) NOT NULL,
    alamat_pengiriman VARCHAR(255) NOT NULL,
    telepon_penerima VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_pelanggan) REFERENCES pelanggan(id_pelanggan) ON DELETE CASCADE
);

-- Tabel detail_pesanan
CREATE TABLE detail_pesanan (
    id_detail_pesanan INT AUTO_INCREMENT PRIMARY KEY,
    id_pesanan INT NOT NULL,
    id_produk INT NOT NULL,
    jumlah INT NOT NULL,
    harga_satuan DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_pesanan) REFERENCES pesanan(id_pesanan) ON DELETE CASCADE,
    FOREIGN KEY (id_produk) REFERENCES produk(id_produk) ON DELETE CASCADE
);

-- Tambahkan data kategori contoh (opsional)
INSERT INTO kategori (nama_kategori) VALUES ('Smartphone'), ('Laptop'), ('Aksesoris');

-- Tambahkan data produk contoh (opsional)
INSERT INTO produk (nama_produk, deskripsi, harga, stok, gambar, id_kategori) VALUES
('Laptop Gaming MSI', 'Laptop gaming dengan spesifikasi tinggi, cocok untuk gamer profesional.', 15000000.00, 10, 'msi_laptop.jpg', 2),
('Samsung Galaxy S23', 'Smartphone flagship dengan kamera canggih dan performa ngebut.', 12000000.00, 25, 'galaxy_s23.jpg', 1),
('Headphone Bluetooth Sony', 'Headphone nirkabel dengan kualitas suara jernih dan noise cancelling.', 1500000.00, 50, 'sony_headphone.jpg', 3);

-- Tambahkan user pelanggan contoh (password 'user123' akan di-hash)
-- Password 'user123' -> hashnya '$2y$10$O0S0Q0R0S0T0U0V0W0X0Y0Z0.b.b.b.b.b.b.b.b.b.b.b' (contoh)
INSERT INTO pelanggan (username, password, email, nama_lengkap, alamat, telepon) VALUES
('user1', '$2y$10$O0S0Q0R0S0T0U0V0W0X0Y0Z0.b.b.b.b.b.b.b.b.b.b.b', 'user1@example.com', 'Budi Santoso', 'Jl. Merdeka No. 10, Jakarta', '081234567890');