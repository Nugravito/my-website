<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "Akses ditolak!";
    exit();
}

$id_produk_edit = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil data produk yang akan diedit
$stmt_get_produk = $koneksi->prepare("SELECT id_produk, nama_produk, harga, stok, gambar, deskripsi, id_kategori FROM produk WHERE id_produk = ?");
if ($stmt_get_produk === false) {
    die("Error preparing statement: " . $koneksi->error);
}
$stmt_get_produk->bind_param("i", $id_produk_edit);
$stmt_get_produk->execute();
$result_produk = $stmt_get_produk->get_result();

if ($result_produk->num_rows > 0) {
    $data_produk = $result_produk->fetch_assoc();
} else {
    echo "<script>alert('Produk tidak ditemukan!'); window.location.href='dashboard_admin.php';</script>";
    exit();
}
$stmt_get_produk->close();


if (isset($_POST['update'])) {
    $nama_produk_baru  = htmlspecialchars(trim($_POST['nama_produk']));
    $harga_baru = (float)$_POST['harga'];
    $stok_baru = (int)$_POST['stok'];
    $deskripsi_baru = htmlspecialchars(trim($_POST['deskripsi']));
    $id_kategori_baru = (int)$_POST['id_kategori'];
    $gambar_lama = $data_produk['gambar']; // Gambar yang sudah ada

    $gambar_baru = $gambar_lama; // Default, jika tidak ada upload baru

    // Validasi input
    if (empty($nama_produk_baru) || empty($harga_baru) || empty($stok_baru) || empty($deskripsi_baru) || empty($id_kategori_baru)) {
        echo "<script>alert('Semua kolom harus diisi!');</script>";
    } elseif ($harga_baru <= 0 || $stok_baru < 0) {
        echo "<script>alert('Harga dan stok harus angka positif!');</script>";
    } else {
        // Penanganan upload gambar baru
        if (!empty($_FILES['gambar']['name'])) {
            $nama_file_upload = $_FILES['gambar']['name'];
            $tmp_name = $_FILES['gambar']['tmp_name'];
            $ukuran_file = $_FILES['gambar']['size'];
            $error_file = $_FILES['gambar']['error'];
            $tipe_file = $_FILES['gambar']['type'];

            $direktori_upload = "img/";
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            $file_extension = strtolower(pathinfo($nama_file_upload, PATHINFO_EXTENSION));

            if ($error_file !== 0) {
                echo "<script>alert('Terjadi kesalahan saat upload gambar baru. Error code: " . $error_file . "');</script>";
            } elseif (!in_array($file_extension, $allowed_extensions)) {
                echo "<script>alert('Format gambar baru tidak diizinkan. Hanya JPG, JPEG, PNG, GIF.');</script>";
            } elseif ($ukuran_file > 5000000) { // Max 5MB
                echo "<script>alert('Ukuran gambar baru terlalu besar. Maksimal 5MB.');</script>";
            } else {
                // Hapus gambar lama jika ada dan bukan gambar default
                if (!empty($gambar_lama) && file_exists($direktori_upload . $gambar_lama)) {
                    unlink($direktori_upload . $gambar_lama);
                }
                // Buat nama file unik untuk gambar baru
                $gambar_baru = uniqid('produk_') . '.' . $file_extension;
                $path_gambar_baru = $direktori_upload . $gambar_baru;

                if (!move_uploaded_file($tmp_name, $path_gambar_baru)) {
                    echo "<script>alert('Gagal mengupload gambar baru.');</script>";
                    $gambar_baru = $gambar_lama; // Kembali ke gambar lama jika gagal upload
                }
            }
        }

        // Update produk di database
        $stmt_update = $koneksi->prepare("UPDATE produk SET nama_produk = ?, harga = ?, stok = ?, gambar = ?, deskripsi = ?, id_kategori = ? WHERE id_produk = ?");
        if ($stmt_update === false) {
            error_log("Error preparing update produk statement: " . $koneksi->error);
            echo "<script>alert('Gagal mengupdate produk: " . $koneksi->error . "');</script>";
        } else {
            $stmt_update->bind_param("sdisisi", $nama_produk_baru, $harga_baru, $stok_baru, $gambar_baru, $deskripsi_baru, $id_kategori_baru, $id_produk_edit);
            if ($stmt_update->execute()) {
                echo "<script>alert('Produk berhasil diubah.'); window.location.href='dashboard_admin.php';</script>";
            } else {
                error_log("Error executing update produk: " . $stmt_update->error);
                echo "<script>alert('Gagal mengubah produk. Silakan coba lagi.');</script>";
            }
            $stmt_update->close();
        }
    }
}

// Ambil daftar kategori untuk dropdown
$kategori_stmt = $koneksi->prepare("SELECT id_kategori, nama_kategori FROM kategori ORDER BY nama_kategori ASC");
$kategori_stmt->execute();
$result_kategori = $kategori_stmt->get_result();
$kategori_list = [];
while($row = $result_kategori->fetch_assoc()) {
    $kategori_list[] = $row;
}
$kategori_stmt->close();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Produk - Toko Elektronik Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group input[type="file"],
        .form-group textarea,
        .form-group select {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }
        .current-image {
            margin-top: 10px;
            margin-bottom: 15px;
        }
        .current-image img {
            max-width: 150px;
            height: auto;
            border: 1px solid #eee;
            border-radius: 4px;
        }
        .btn-submit {
            padding: 12px 25px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1.1em;
            width: 100%;
            box-sizing: border-box;
            margin-top: 15px;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Edit Produk</h1>
        <nav>
            <a href="dashboard_admin.php">Kembali ke Dashboard</a>
        </nav>
    </div>

    <div class="form-container">
        <h2>Edit Produk: <?php echo htmlspecialchars($data_produk['nama_produk']); ?></h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nama_produk">Nama Produk:</label>
                <input type="text" id="nama_produk" name="nama_produk" value="<?php echo htmlspecialchars($data_produk['nama_produk']); ?>" required>
            </div>
            <div class="form-group">
                <label for="harga">Harga:</label>
                <input type="number" id="harga" name="harga" step="0.01" min="0" value="<?php echo htmlspecialchars($data_produk['harga']); ?>" required>
            </div>
            <div class="form-group">
                <label for="stok">Stok:</label>
                <input type="number" id="stok" name="stok" min="0" value="<?php echo htmlspecialchars($data_produk['stok']); ?>" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi Produk:</label>
                <textarea id="deskripsi" name="deskripsi" rows="5" required><?php echo htmlspecialchars($data_produk['deskripsi']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="id_kategori">Kategori:</label>
                <select id="id_kategori" name="id_kategori" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($kategori_list as $kategori): ?>
                        <option value="<?php echo htmlspecialchars($kategori['id_kategori']); ?>" <?php echo ($kategori['id_kategori'] == $data_produk['id_kategori']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kategori['nama_kategori']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="gambar">Gambar Produk Saat Ini:</label>
                <?php if (!empty($data_produk['gambar'])): ?>
                    <div class="current-image">
                        <img src="img/<?php echo htmlspecialchars($data_produk['gambar']); ?>" alt="Gambar Saat Ini">
                    </div>
                <?php else: ?>
                    <p>Tidak ada gambar saat ini.</p>
                <?php endif; ?>
                <label for="gambar">Upload Gambar Baru (kosongkan jika tidak ingin mengubah):</label>
                <input type="file" id="gambar" name="gambar" accept="image/*">
            </div>
            <button type="submit" name="update" class="btn-submit">Update Produk</button>
        </form>
    </div>
</body>
</html>