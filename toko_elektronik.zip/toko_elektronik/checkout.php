<?php
session_start();
include 'koneksi.php';

// Pastikan pelanggan sudah login
if (!isset($_SESSION['id_pelanggan']) || $_SESSION['level'] != 'user') {
    // Simpan halaman tujuan agar bisa redirect kembali setelah login
    $_SESSION['redirect_after_login'] = 'checkout.php';
    header("location:login.php");
    exit();
}
$id_pelanggan = $_SESSION['id_pelanggan']; // Dapatkan ID pelanggan dari sesi

// --- Bagian 1: Tampilkan Ringkasan Keranjang dan Form Pengiriman ---
$keranjang = isset($_SESSION['keranjang']) ? $_SESSION['keranjang'] : [];
$grand_total = 0;
if (!empty($keranjang)) {
    foreach ($keranjang as $id => $item) {
        $grand_total += ($item['harga'] * $item['quantity']);
    }
}

// --- Bagian 2: Proses Submit Form Checkout ---
if (isset($_POST['submit_checkout'])) {
    if (empty($keranjang)) {
        echo "<script>alert('Keranjang Anda kosong, tidak bisa checkout.'); window.location.href='index.php';</script>";
        exit();
    }

    // Validasi dan sanitasi data yang diterima
    $nama_penerima = htmlspecialchars(trim($_POST['nama_penerima']));
    $alamat_pengiriman = htmlspecialchars(trim($_POST['alamat_pengiriman']));
    $telepon_penerima = htmlspecialchars(trim($_POST['telepon_penerima']));

    // Periksa apakah input tidak kosong
    if (empty($nama_penerima) || empty($alamat_pengiriman) || empty($telepon_penerima)) {
        echo "<script>alert('Semua kolom informasi pengiriman harus diisi!'); window.location.href='checkout.php';</script>";
        exit();
    }

    // Mulai transaksi database
    mysqli_autocommit($koneksi, FALSE); // Matikan autocommit
    $berhasil_transaksi = true;

    // 1. Masukkan data pesanan ke tabel 'pesanan'
    $stmt_pesanan = $koneksi->prepare("INSERT INTO pesanan (id_pelanggan, tanggal_pesanan, total_harga, status_pesanan, nama_penerima, alamat_pengiriman, telepon_penerima) VALUES (?, NOW(), ?, ?, ?, ?, ?)");
    if ($stmt_pesanan === false) {
        $berhasil_transaksi = false;
        error_log("Error preparing statement for pesanan: " . $koneksi->error);
    } else {
        $status_pesanan = 'pending'; // Status awal
        $stmt_pesanan->bind_param("idsss", $id_pelanggan, $grand_total, $status_pesanan, $nama_penerima, $alamat_pengiriman, $telepon_penerima);
        if (!$stmt_pesanan->execute()) {
            $berhasil_transaksi = false;
            error_log("Error inserting pesanan: " . $stmt_pesanan->error);
        }
        $id_pesanan_baru = $stmt_pesanan->insert_id;
        $stmt_pesanan->close();
    }

    // 2. Masukkan detail pesanan ke tabel 'detail_pesanan' dan update stok produk
    if ($berhasil_transaksi) {
        $stmt_detail = $koneksi->prepare("INSERT INTO detail_pesanan (id_pesanan, id_produk, jumlah, harga_satuan) VALUES (?, ?, ?, ?)");
        $stmt_update_stok = $koneksi->prepare("UPDATE produk SET stok = stok - ? WHERE id_produk = ? AND stok >= ?");

        foreach ($keranjang as $id_produk_item => $item) {
            if (!$berhasil_transaksi) break; // Jika ada error sebelumnya, keluar loop

            // Masukkan detail pesanan
            if ($stmt_detail === false) {
                $berhasil_transaksi = false;
                error_log("Error preparing statement for detail_pesanan: " . $koneksi->error);
                break;
            }
            $stmt_detail->bind_param("iiid", $id_pesanan_baru, $item['id_produk'], $item['quantity'], $item['harga']);
            if (!$stmt_detail->execute()) {
                $berhasil_transaksi = false;
                error_log("Error inserting detail_pesanan for product " . $item['id_produk'] . ": " . $stmt_detail->error);
            }

            // Update stok produk
            if ($stmt_update_stok === false) {
                $berhasil_transaksi = false;
                error_log("Error preparing statement for update stok: " . $koneksi->error);
                break;
            }
            $current_qty = $item['quantity'];
            $stmt_update_stok->bind_param("iii", $current_qty, $item['id_produk'], $current_qty); // update stok = stok - jumlah WHERE id_produk = id_produk AND stok >= jumlah
            if (!$stmt_update_stok->execute()) {
                $berhasil_transaksi = false;
                error_log("Error updating stok for product " . $item['id_produk'] . ": " . $stmt_update_stok->error);
            }
             if ($stmt_update_stok->affected_rows === 0) {
                // Ini berarti stok tidak cukup (stok < jumlah yang dibeli) atau produk tidak ditemukan
                $berhasil_transaksi = false;
                error_log("Stok tidak cukup atau produk tidak ditemukan untuk produk ID: " . $item['id_produk']);
                echo "<script>alert('Stok produk " . htmlspecialchars($item['nama_produk']) . " tidak mencukupi!');</script>";
                break;
            }
        }
        $stmt_detail->close();
        $stmt_update_stok->close();
    }

    // Finalisasi transaksi
    if ($berhasil_transaksi) {
        mysqli_commit($koneksi); // Commit perubahan
        unset($_SESSION['keranjang']); // Kosongkan keranjang setelah checkout berhasil
        echo "<script>alert('Pesanan berhasil dibuat! Terima kasih telah berbelanja.'); window.location.href='riwayat_pesanan.php';</script>";
        exit();
    } else {
        mysqli_rollback($koneksi); // Batalkan semua perubahan jika ada error
        echo "<script>alert('Gagal membuat pesanan. Silakan coba lagi. (Error: " . $koneksi->error . ")'); window.location.href='checkout.php';</script>";
        exit();
    }
    mysqli_autocommit($koneksi, TRUE); // Aktifkan kembali autocommit
}

// Redirect jika keranjang kosong dan belum ada submit checkout
if (empty($keranjang) && !isset($_POST['submit_checkout'])) {
    echo "<script>alert('Keranjang Anda kosong. Silakan belanja terlebih dahulu.'); window.location.href='index.php';</script>";
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .checkout-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .order-summary table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .order-summary th, .order-summary td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .order-summary th {
            background-color: #f2f2f2;
        }
        .total-checkout {
            text-align: right;
            font-size: 1.2em;
            font-weight: bold;
            margin-top: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group textarea {
            width: calc(100% - 22px); /* Padding and border */
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }
        .btn-submit {
            padding: 12px 25px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1.1em;
            width: 100%;
            box-sizing: border-box; /* Include padding in width */
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Toko Elektronik</h1>
        <nav>
            <a href="index.php">Beranda</a> |
            <a href="keranjang.php">Keranjang</a> |
            <?php if (isset($_SESSION['level'])): ?>
                <?php if ($_SESSION['level'] == 'admin'): ?>
                    <a href="dashboard_admin.php">Dashboard Admin</a> |
                <?php else: ?>
                    <a href="riwayat_pesanan.php">Riwayat Pesanan</a> |
                <?php endif; ?>
                <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span> |
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a> |
                <a href="register.php">Daftar</a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="checkout-container">
        <h2>Ringkasan Pesanan</h2>
        <?php if (empty($keranjang)): ?>
            <p>Keranjang Anda kosong. <a href="index.php">Kembali ke Beranda</a></p>
        <?php else: ?>
            <div class="order-summary">
                <table>
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Harga Satuan</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($keranjang as $item_id => $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['nama_produk']); ?></td>
                                <td>Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                <td>Rp <?php echo number_format($item['harga'] * $item['quantity'], 0, ',', '.'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="total-checkout">
                    Total Keseluruhan: Rp <?php echo number_format($grand_total, 0, ',', '.'); ?>
                </div>
            </div>

            <h2>Informasi Pengiriman</h2>
            <form action="checkout.php" method="POST">
                <div class="form-group">
                    <label for="nama_penerima">Nama Penerima:</label>
                    <input type="text" id="nama_penerima" name="nama_penerima" required value="<?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="alamat_pengiriman">Alamat Pengiriman:</label>
                    <textarea id="alamat_pengiriman" name="alamat_pengiriman" rows="4" required><?php
                    // Coba ambil alamat dari data pelanggan jika sudah ada di sesi
                    // Ini memerlukan penambahan alamat di sesi saat login, atau query ke tabel pelanggan
                    if (isset($_SESSION['alamat_pengiriman'])) {
                        echo htmlspecialchars($_SESSION['alamat_pengiriman']);
                    }
                    ?></textarea>
                </div>
                <div class="form-group">
                    <label for="telepon_penerima">Nomor Telepon:</label>
                    <input type="text" id="telepon_penerima" name="telepon_penerima" required value="<?php
                    // Coba ambil telepon dari data pelanggan jika sudah ada di sesi
                    if (isset($_SESSION['telepon_penerima'])) {
                        echo htmlspecialchars($_SESSION['telepon_penerima']);
                    }
                    ?>">
                </div>
                <button type="submit" name="submit_checkout" class="btn-submit">Selesaikan Pesanan</button>
            </form>
        <?php endif; ?>
        <p class="back-link"><a href="keranjang.php">Kembali ke Keranjang</a></p>
    </div>
</body>
</html>