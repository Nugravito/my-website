<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "Akses ditolak!";
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin - Toko Elektronik</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .admin-nav {
            margin-bottom: 20px;
        }
        .admin-nav a {
            padding: 8px 15px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-right: 10px;
        }
        .admin-nav a:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        td img {
            max-width: 50px;
            height: auto;
        }
        .action-links a {
            margin-right: 5px;
            color: #007bff;
            text-decoration: none;
        }
        .action-links a:hover {
            text-decoration: underline;
        }
        .delete-link {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Dashboard Admin</h1>
        <nav class="admin-nav">
            <a href="tambah_produk.php">Tambah Produk</a>
            <a href="tambah_user_admin.php">Tambah Admin</a>
            <a href="logout.php">Logout</a>
        </nav>
        <span>Selamat Datang, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
    </div>

    <h3>Daftar Produk</h3>
    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Gambar</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            // Gunakan Prepared Statement
            $stmt = $koneksi->prepare("SELECT id_produk, nama_produk, harga, stok, gambar FROM produk ORDER BY id_produk DESC");
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while ($data = $result->fetch_assoc()) {
            ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($data['nama_produk']); ?></td>
                    <td>Rp <?= number_format($data['harga'], 0, ',', '.'); ?></td>
                    <td><?= htmlspecialchars($data['stok']); ?></td>
                    <td><img src="img/<?= htmlspecialchars($data['gambar']); ?>" width="50" alt="<?= htmlspecialchars($data['nama_produk']); ?>"></td>
                    <td class="action-links">
                        <a href="edit_produk.php?id=<?= htmlspecialchars($data['id_produk']); ?>">Edit</a> |
                        <a href="hapus_produk.php?id=<?= htmlspecialchars($data['id_produk']); ?>" class="delete-link" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">Hapus</a>
                    </td>
                </tr>
            <?php
                }
            } else {
                echo "<tr><td colspan='6'>Belum ada produk.</td></tr>";
            }
            $stmt->close();
            ?>
        </tbody>
    </table>
</body>
</html>