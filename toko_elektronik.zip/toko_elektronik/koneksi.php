<?php
// koneksi.php
// Pastikan tidak ada spasi atau karakter lain sebelum <?php

// Konfigurasi koneksi database
// Ganti nilai-nilai ini dengan detail dari provider hosting Anda!
// Host: Biasanya "localhost", tapi bisa juga IP address atau nama host spesifik (cek cPanel/dokumentasi hosting)
$host = "localhost";
// User: Username database yang Anda buat di cPanel/Plesk (bukan user cPanel)
$user = "nama_user_database_hosting"; // Contoh: cpaneluser_dbuser
// Pass: Password untuk user database tersebut
$pass = "password_kuat_anda"; // Contoh: PasswordKuatAnda123!
// Db: Nama database yang Anda buat di cPanel/Plesk (biasanya dengan awalan username cPanel)
$db   = "nama_database_hosting"; // Contoh: cpaneluser_tokoel

// Buat koneksi ke database
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Periksa koneksi
if (!$koneksi) {
    // Di lingkungan produksi, JANGAN tampilkan detail error ke pengguna.
    // Catat (log) error ini untuk debugging dan tampilkan pesan generik.
    error_log("Koneksi database gagal: " . mysqli_connect_error()); // Catat error ke log server
    die("Maaf, terjadi masalah koneksi database. Silakan coba lagi nanti."); // Pesan ramah pengguna
}

// Opsional: Atur charset untuk koneksi (penting untuk mendukung karakter khusus)
mysqli_set_charset($koneksi, "utf8mb4");

?>