<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "Akses ditolak!";
    exit();
}

if (isset($_GET['id'])) {
    $id_produk_hapus = (int)$_GET['id'];

    // Ambil nama file gambar sebelum menghapus data produk dari database
    $stmt_get_gambar = $koneksi->prepare("SELECT gambar FROM produk WHERE id_produk = ?");
    $stmt_get_gambar->bind_param("i", $id_produk_hapus);
    $stmt_get_gambar->execute();
    $result_gambar = $stmt_get_gambar->get_result();
    $data_gambar = $result_gambar->fetch_assoc();
    $nama_gambar = $data_gambar['gambar'] ?? '';
    $stmt_get_gambar->close();

    // Hapus produk dari database
    $stmt_delete = $koneksi->prepare("DELETE FROM produk WHERE id_produk = ?");
    if ($stmt_delete === false) {
        error_log("Error preparing delete produk statement: " . $koneksi->error);
        echo "<script>alert('Gagal menghapus produk: " . $koneksi->error . "'); window.location.href='dashboard_admin.php';</script>";
        exit();
    }
    $stmt_delete->bind_param("i", $id_produk_hapus);

    if ($stmt_delete->execute()) {
        // Hapus file gambar dari server jika ada
        $path_gambar = "img/" . $nama_gambar;
        if (!empty($nama_gambar) && file_exists($path_gambar) && is_file($path_gambar)) {
            unlink($path_gambar);
        }
        echo "<script>alert('Produk berhasil dihapus.'); window.location.href='dashboard_admin.php';</script>";
    } else {
        error_log("Error executing delete produk: " . $stmt_delete->error);
        echo "<script>alert('Gagal menghapus produk. Silakan coba lagi.'); window.location.href='dashboard_admin.php';</script>";
    }
    $stmt_delete->close();
} else {
    header("location:dashboard_admin.php");
    exit();
}
?>