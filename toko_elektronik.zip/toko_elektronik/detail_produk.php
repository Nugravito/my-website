<?php
session_start();
include 'koneksi.php';

// Ambil ID produk dari URL
if (isset($_GET['id'])) {
    // Sanitize dan cast ke integer untuk keamanan
    $id_produk = (int)$_GET['id'];

    // Query untuk mendapatkan detail produk berdasarkan ID
    // Gunakan Prepared Statement untuk keamanan SQL Injection
    $sql = "SELECT p.id_produk, p.nama_produk, p.deskripsi, p.harga, p.stok, p.gambar, k.nama_kategori
            FROM produk AS p
            LEFT JOIN kategori AS k ON p.id_kategori = k.id_kategori
            WHERE p.id_produk = ?";

    $stmt = $koneksi->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $koneksi->error); // Lebih baik log error ini di produksi
    }
    $stmt->bind_param("i", $id_produk); // "i" berarti integer
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $produk = $result->fetch_assoc(); // Ambil satu baris data produk
    } else {
        // Jika produk tidak ditemukan, arahkan kembali ke halaman index atau tampilkan pesan error
        echo "<script>alert('Produk tidak ditemukan!'); window.location.href='index.php';</script>";
        exit();
    }
    $stmt->close();
} else {
    // Jika tidak ada ID produk di URL, arahkan kembali ke halaman index
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($produk['nama_produk']); ?> - Toko Elektronik</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Tambahkan CSS spesifik untuk detail produk jika ada */
        .product-detail-container {
            display: flex;
            gap: 30px;
            margin-top: 30px;
            flex-wrap: wrap; /* Untuk responsif */
        }
        .image-section {
            flex: 1;
            min-width: 300px;
        }
        .image-section img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .product-details-section {
            flex: 2;
            min-width: 300px;
        }
        .product-details-section h1 {
            color: #333;
            margin-top: 0;
        }
        .category {
            display: block;
            margin-bottom: 10px;
            color: #777;
            font-size: 0.9em;
        }
        .price {
            font-size: 1.8em;
            color: #007bff;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .stock {
            color: #555;
            margin-bottom: 20px;
        }
        .add-to-cart-form {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
        }
        .add-to-cart-form input[type="number"] {
            width: 60px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
        }
        .add-to-cart-form button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1em;
        }
        .add-to-cart-form button:hover {
            background-color: #218838;
        }
        .back-link {
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Toko Elektronik</h1>
        <nav>
            <a href="index.php">Beranda</a> |
            <a href="keranjang.php">Keranjang</a> |
            <?php if (isset($_SESSION['level'])): ?>
                <?php if ($_SESSION['level'] == 'admin'): ?>
                    <a href="dashboard_admin.php">Dashboard Admin</a> |
                <?php else: ?>
                    <a href="riwayat_pesanan.php">Riwayat Pesanan</a> |
                <?php endif; ?>
                <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span> |
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a> |
                <a href="register.php">Daftar</a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="product-detail-container">
        <div class="image-section">
            <img src="img/<?php echo htmlspecialchars($produk['gambar']); ?>" alt="<?php echo htmlspecialchars($produk['nama_produk']); ?>">
        </div>
        <div class="product-details-section">
            <h1><?php echo htmlspecialchars($produk['nama_produk']); ?></h1>
            <span class="category">Kategori: <?php echo htmlspecialchars($produk['nama_kategori'] ?? 'Tidak Berkategori'); ?></span>
            <p class="price">Rp <?php echo number_format($produk['harga'], 0, ',', '.'); ?></p>
            <p class="stock">Stok Tersedia: <?php echo htmlspecialchars($produk['stok']); ?> unit</p>

            <h3>Deskripsi Produk:</h3>
            <p><?php echo nl2br(htmlspecialchars($produk['deskripsi'])); ?></p>
            
            <form action="keranjang.php" method="GET" class="add-to-cart-form">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($produk['id_produk']); ?>">
                <label for="qty">Jumlah:</label>
                <input type="number" id="qty" name="qty" value="1" min="1" max="<?php echo htmlspecialchars($produk['stok']); ?>">
                <button type="submit">Tambah ke Keranjang</button>
            </form>
        </div>
    </div>
    <div class="back-link">
        <a href="index.php">Kembali ke Daftar Produk</a>
    </div>
</body>
</html>