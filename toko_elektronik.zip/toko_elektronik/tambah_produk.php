<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "Akses ditolak!";
    exit();
}

if (isset($_POST['submit'])) {
    $nama_produk  = htmlspecialchars(trim($_POST['nama_produk']));
    $harga = (float)$_POST['harga']; // Cast to float for DECIMAL type
    $stok = (int)$_POST['stok']; // Cast to int
    $deskripsi = htmlspecialchars(trim($_POST['deskripsi'])); // New: deskripsi
    $id_kategori = (int)$_POST['id_kategori']; // New: kategori

    $gambar = $_FILES['gambar']['name'];
    $tmp_name = $_FILES['gambar']['tmp_name'];
    $ukuran_file = $_FILES['gambar']['size'];
    $error_file = $_FILES['gambar']['error'];
    $tipe_file = $_FILES['gambar']['type'];

    $direktori_upload = "img/";
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
    $file_extension = strtolower(pathinfo($gambar, PATHINFO_EXTENSION));

    // Validasi input dan file upload
    if (empty($nama_produk) || empty($harga) || empty($stok) || empty($deskripsi) || empty($id_kategori)) {
        echo "<script>alert('Semua kolom harus diisi!');</script>";
    } elseif ($harga <= 0 || $stok < 0) {
        echo "<script>alert('Harga dan stok harus angka positif!');</script>";
    } elseif ($error_file !== 0) {
        echo "<script>alert('Terjadi kesalahan saat upload gambar. Error code: " . $error_file . "');</script>";
    } elseif (!in_array($file_extension, $allowed_extensions)) {
        echo "<script>alert('Format gambar tidak diizinkan. Hanya JPG, JPEG, PNG, GIF.');</script>";
    } elseif ($ukuran_file > 5000000) { // Max 5MB
        echo "<script>alert('Ukuran gambar terlalu besar. Maksimal 5MB.');</script>";
    } else {
        // Buat nama file unik untuk mencegah konflik
        $nama_file_unik = uniqid('produk_') . '.' . $file_extension;
        $path_gambar = $direktori_upload . $nama_file_unik;

        if (move_uploaded_file($tmp_name, $path_gambar)) {
            // Gunakan Prepared Statement untuk INSERT produk
            $stmt = $koneksi->prepare("INSERT INTO produk (nama_produk, harga, stok, gambar, deskripsi, id_kategori) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt === false) {
                error_log("Error preparing insert produk statement: " . $koneksi->error);
                echo "<script>alert('Gagal menambahkan produk: " . $koneksi->error . "');</script>"; // Di produksi, jangan tampilkan $koneksi->error
            } else {
                $stmt->bind_param("sdisis", $nama_produk, $harga, $stok, $nama_file_unik, $deskripsi, $id_kategori); // s:string, d:double, i:integer, s:string, i:integer, s:string
                if ($stmt->execute()) {
                    echo "<script>alert('Produk berhasil ditambahkan.'); window.location.href='dashboard_admin.php';</script>";
                } else {
                    error_log("Error executing insert produk: " . $stmt->error);
                    echo "<script>alert('Gagal menambahkan produk. Silakan coba lagi.');</script>";
                }
                $stmt->close();
            }
        } else {
            echo "<script>alert('Gagal mengupload gambar.');</script>";
        }
    }
}

// Ambil daftar kategori untuk dropdown
$kategori_stmt = $koneksi->prepare("SELECT id_kategori, nama_kategori FROM kategori ORDER BY nama_kategori ASC");
$kategori_stmt->execute();
$result_kategori = $kategori_stmt->get_result();
$kategori_list = [];
while($row = $result_kategori->fetch_assoc()) {
    $kategori_list[] = $row;
}
$kategori_stmt->close();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Produk Baru - Toko Elektronik Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group input[type="file"],
        .form-group textarea,
        .form-group select {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }
        .btn-submit {
            padding: 12px 25px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1.1em;
            width: 100%;
            box-sizing: border-box;
            margin-top: 15px;
        }
        .btn-submit:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Tambah Produk Baru</h1>
        <nav>
            <a href="dashboard_admin.php">Kembali ke Dashboard</a>
        </nav>
    </div>

    <div class="form-container">
        <h2>Form Tambah Produk</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nama_produk">Nama Produk:</label>
                <input type="text" id="nama_produk" name="nama_produk" required>
            </div>
            <div class="form-group">
                <label for="harga">Harga:</label>
                <input type="number" id="harga" name="harga" step="0.01" min="0" required>
            </div>
            <div class="form-group">
                <label for="stok">Stok:</label>
                <input type="number" id="stok" name="stok" min="0" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi Produk:</label>
                <textarea id="deskripsi" name="deskripsi" rows="5" required></textarea>
            </div>
            <div class="form-group">
                <label for="id_kategori">Kategori:</label>
                <select id="id_kategori" name="id_kategori" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($kategori_list as $kategori): ?>
                        <option value="<?php echo htmlspecialchars($kategori['id_kategori']); ?>">
                            <?php echo htmlspecialchars($kategori['nama_kategori']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="gambar">Gambar Produk:</label>
                <input type="file" id="gambar" name="gambar" accept="image/*" required>
            </div>
            <button type="submit" name="submit" class="btn-submit">Tambah Produk</button>
        </form>
    </div>
</body>
</html>