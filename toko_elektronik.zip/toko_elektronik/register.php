<?php
session_start(); // Pastikan sesi dimulai
include 'koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Akun - Toko Elektronik</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f7f7f7;
            margin: 0;
        }
        .register-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .register-container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }
        .btn-submit {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1.1em;
            width: 100%;
            box-sizing: border-box;
            margin-top: 15px;
        }
        .btn-submit:hover {
            background-color: #218838;
        }
        .login-link {
            margin-top: 20px;
            font-size: 0.9em;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 4px;
            font-size: 0.95em;
        }
        .success-message {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Daftar Akun Baru</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="daftar" class="btn-submit">Daftar</button>
        </form>

        <?php
        if (isset($_POST['daftar'])) {
            $username = htmlspecialchars(trim($_POST['username']));
            $email = htmlspecialchars(trim($_POST['email']));
            $password_input = $_POST['password']; // Ambil plain text password
            $hashed_password = password_hash($password_input, PASSWORD_DEFAULT); // Hash password

            // Validasi input
            if (empty($username) || empty($email) || empty($password_input)) {
                echo "<p class='message error-message'>Semua kolom harus diisi.</p>";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "<p class='message error-message'>Format email tidak valid.</p>";
            } else {
                // Periksa apakah username atau email sudah terdaftar
                $stmt_check = $koneksi->prepare("SELECT COUNT(*) FROM user WHERE username = ? OR email = ?");
                if ($stmt_check === false) {
                    error_log("Error preparing check user statement: " . $koneksi->error);
                    echo "<p class='message error-message'>Terjadi masalah sistem saat pendaftaran. Silakan coba lagi.</p>";
                } else {
                    $stmt_check->bind_param("ss", $username, $email);
                    $stmt_check->execute();
                    $stmt_check->bind_result($count);
                    $stmt_check->fetch();
                    $stmt_check->close();

                    if ($count > 0) {
                        echo "<p class='message error-message'>Username atau Email sudah terdaftar.</p>";
                    } else {
                        // Masukkan user baru ke tabel 'user' (sebagai pelanggan)
                        $stmt_insert = $koneksi->prepare("INSERT INTO user (username, password, level) VALUES (?, ?, 'user')");
                        if ($stmt_insert === false) {
                            error_log("Error preparing insert user statement: " . $koneksi->error);
                            echo "<p class='message error-message'>Terjadi masalah sistem saat pendaftaran. Silakan coba lagi.</p>";
                        } else {
                            $stmt_insert->bind_param("ss", $username, $hashed_password);
                            if ($stmt_insert->execute()) {
                                // Jika tabel pelanggan terpisah, Anda juga harus insert ke tabel pelanggan di sini
                                // $id_user_baru = $stmt_insert->insert_id;
                                // $stmt_insert_pelanggan = $koneksi->prepare("INSERT INTO pelanggan (id_pelanggan, username, email, password) VALUES (?, ?, ?, ?)");
                                // $stmt_insert_pelanggan->bind_param("isss", $id_user_baru, $username, $email, $hashed_password);
                                // $stmt_insert_pelanggan->execute();
                                // $stmt_insert_pelanggan->close();

                                echo "<p class='message success-message'>Registrasi berhasil! Silakan <a href='login.php'>Login sekarang</a>.</p>";
                            } else {
                                error_log("Error executing insert user: " . $stmt_insert->error);
                                echo "<p class='message error-message'>Gagal mendaftar. Terjadi kesalahan.</p>";
                            }
                            $stmt_insert->close();
                        }
                    }
                }
            }
        }
        ?>
        <p class="login-link">Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>
</body>
</html>