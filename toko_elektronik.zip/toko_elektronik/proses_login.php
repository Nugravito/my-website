<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars(trim($_POST['username']));
    $input_password = $_POST['password'];

    // Gunakan Prepared Statement untuk mencari user
    $stmt = $koneksi->prepare("SELECT id, username, password, level FROM user WHERE username = ?");
    if ($stmt === false) {
        error_log("Error preparing statement for login: " . $koneksi->error);
        header("location:login.php?error=Terjadi masalah sistem. Silakan coba lagi.");
        exit();
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verifikasi password yang diinput dengan hashed password dari database
        if (password_verify($input_password, $user['password'])) {
            // Login berhasil
            $_SESSION['id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['level'] = $user['level'];

            // Jika user adalah pelanggan, simpan juga id_pelanggan
            // Asumsi: Jika user level 'user', maka id di tabel 'user' adalah id_pelanggan
            if ($user['level'] == 'user') {
                $_SESSION['id_pelanggan'] = $user['id'];
                // Anda juga bisa ambil data lain dari tabel pelanggan di sini jika tabel user dan pelanggan terpisah
                // Misal: SELECT id_pelanggan, nama_lengkap, alamat, telepon FROM pelanggan WHERE username = ?
                // Kemudian simpan ke $_SESSION
            }


            // Redirect berdasarkan level atau tujuan sebelumnya
            if ($user['level'] == 'admin') {
                header("location:dashboard_admin.php");
            } else {
                // Redirect ke halaman yang disimpan sebelumnya, jika ada (misal dari checkout)
                if (isset($_SESSION['redirect_after_login'])) {
                    $redirect_page = $_SESSION['redirect_after_login'];
                    unset($_SESSION['redirect_after_login']); // Hapus setelah digunakan
                    header("location:" . $redirect_page);
                } else {
                    header("location:index.php");
                }
            }
            exit();
        } else {
            // Password salah
            header("location:login.php?error=Username atau password salah.");
            exit();
        }
    } else {
        // Username tidak ditemukan
        header("location:login.php?error=Username atau password salah.");
        exit();
    }
    $stmt->close();
} else {
    // Jika diakses tidak melalui POST, arahkan ke halaman login
    header("location:login.php");
    exit();
}
?>